import{p as r}from"./DDj3sgx-.js";const t={get error(){return r.error},get params(){return r.params},get status(){return r.status},get url(){return r.url}},a=t;export{a as p};
